function gui1
figure('Name','GUI1')
end