function gui2
figure('Name','GUI2')
end