
% Parameters for MotorSpeedModeling.slx abd MotorSpeedControlSimulink.slx
J = 0.01;
b = 0.1;
Ke = 0.01;
Kt = 0.01;
R = 1;
L = 0.5;
