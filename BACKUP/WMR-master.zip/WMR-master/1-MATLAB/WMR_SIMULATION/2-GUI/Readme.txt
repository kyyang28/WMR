
1. Check simulation results in folder 'RESULTS'

2. ProjectCore folders contains all the GUI files and M-files related to this project

3. Login GUI files contains the main entry program of this project
