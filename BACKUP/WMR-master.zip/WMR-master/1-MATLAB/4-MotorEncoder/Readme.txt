
This MATLAB GUI program directly control two motors' speeds.

No need to burn arduino codes (using Arduino IDE) onto WMR
