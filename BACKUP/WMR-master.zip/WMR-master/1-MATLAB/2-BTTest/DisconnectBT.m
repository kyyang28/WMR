
% disconnect bt object
fclose(bt);
clear('bt');
