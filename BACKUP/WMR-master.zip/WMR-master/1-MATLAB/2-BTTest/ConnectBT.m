
% create bt object
bt = Bluetooth('WMR_BT',1);

% connect bt object
fopen(bt);
