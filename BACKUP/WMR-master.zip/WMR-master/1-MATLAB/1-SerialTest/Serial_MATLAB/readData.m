function [] = readData(s)

fprintf(s, 'R');
% fprintf(s, '1');

var = fscanf(s, '%u')

end
